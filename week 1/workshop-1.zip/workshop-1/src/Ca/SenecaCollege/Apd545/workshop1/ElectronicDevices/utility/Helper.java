package Ca.SenecaCollege.Apd545.workshop1.ElectronicDevices.utility;

public abstract class Helper implements IDeviceMaintainable{

    @Override
    public abstract String getMaintenanceInstructions();
}
