/*
Workshop: 1
Name: KRUTIN BHARATBHAI POLRA
Id: 135416220
*/

package Ca.SenecaCollege.Apd545.workshop1.ElectronicDevices.utility;

public interface IDeviceMaintainable {
    String getMaintenanceInstructions();
}
