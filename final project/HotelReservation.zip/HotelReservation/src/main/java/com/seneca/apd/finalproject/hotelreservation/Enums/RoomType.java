package com.seneca.apd.finalproject.hotelreservation.Enums;

public enum RoomType {
    SINGLE,
    DOUBLE,
    DELUXE,
    PENTHOUSE
}